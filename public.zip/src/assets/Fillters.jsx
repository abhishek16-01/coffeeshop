import React from 'react'
import { Button, Container } from 'react-bootstrap'
import Form from 'react-bootstrap/Form';

function Fillters() {
  return (
    <div>

        <Container >

            <Form.Check type='radio'  label='Ascending' name='r1'/>

            <Form.Check type='radio'  label='Descending' name='r1'/>

            <Form.Check type='chekbox'  label='Out Of Stock' name='r1'/>

            <Button  variant="danger"> Clear Fillter</Button>
        </Container>
    </div>
  )
}

export default Fillters