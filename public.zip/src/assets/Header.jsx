import React from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { NavLink } from 'react-router-dom';

function Header() {
    return (
        <div>
            <Navbar bg="dark" data-bs-theme="dark">
                <Container>
                    <Navbar.Brand to="/"><img src="./images/logo.png" alt="" /></Navbar.Brand>
                    <Nav className="">
                        <NavLink to="/">Home</NavLink>
                        <NavLink to="/About">About</NavLink>
                        <NavLink to="/Gallery">Gallery</NavLink>
                        <NavLink to="/Services">Services</NavLink>
                        <NavLink to="/Contactus">Contact US</NavLink>
                        
                    </Nav>
                </Container>
            </Navbar>
        </div>
    )
}

export default Header